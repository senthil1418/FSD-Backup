package com.cognizant.genc.sampleapp.user.dao;

import java.util.List;
import com.cognizant.genc.sampleapp.model.User;

public interface UserDao {
    public void add(User user);
    public List<User> findAll();
    public User findById(Integer id);
    public User updateUser(Integer id, String name);
    public Boolean remove(Integer id);
}