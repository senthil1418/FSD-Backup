package com.cognizant.genc.sampleapp.user.service;

import java.util.List;
import com.cognizant.genc.sampleapp.model.User;

public interface UserService {
    public List<User> findAll();
    public Boolean add(User user);
    public User updateName(Integer id, String name);
    public Boolean delete(Integer id);
    public User findById(String id);
}