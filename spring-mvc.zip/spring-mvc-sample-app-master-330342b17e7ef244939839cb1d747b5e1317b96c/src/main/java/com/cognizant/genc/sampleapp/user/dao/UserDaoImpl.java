package com.cognizant.genc.sampleapp.user.dao;

import java.util.List;
import org.apache.log4j.Logger;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
// import javax.persistence.criteria.CriteriaBuilder;
// import javax.persistence.criteria.CriteriaUpdate;
// import javax.persistence.criteria.Root;

import org.springframework.stereotype.Component;
import com.cognizant.genc.sampleapp.model.User;

@Component
public class UserDaoImpl implements UserDao{

	private static Logger log = Logger.getLogger(UserDaoImpl.class);

	@PersistenceContext
	private EntityManager em;
	
	public void add(User user) {
		int id = (int) (Math.random()*10000); //temporary
		user.setId(id);
		em.persist(user);
	}

	public List<User> findAll() {
		return em.createQuery("SELECT u FROM User u").getResultList();
	}

	public User findById(Integer id) {
		return em.find(User.class, id);
	}
	
	/*public void updateUser(Integer id, String name) {
		CriteriaBuilder cb = this.em.getCriteriaBuilder();
		CriteriaUpdate<User> update = cb.createCriteriaUpdate(User.class);
		// set the root class
        Root e = update.from(User.class);

        // set update and where clause
        update.set("name", name);
        update.where(cb.equal(e.get("id"), id));

        // perform update
        this.em.createQuery(update).executeUpdate();
	}*/

	public User updateUser(Integer id, String name) {
		User user = em.find(User.class, id);
		user.setName(name);
		return user;
	}

	public Boolean remove(Integer id) {
		User user = em.find(User.class, id);
		em.remove(user);
		return true;
	}
}