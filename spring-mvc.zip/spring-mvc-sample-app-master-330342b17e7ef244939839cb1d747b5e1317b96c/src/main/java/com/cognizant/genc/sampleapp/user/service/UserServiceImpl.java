package com.cognizant.genc.sampleapp.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import com.cognizant.genc.sampleapp.user.dao.UserDao;
import com.cognizant.genc.sampleapp.model.User;

@Service("userService")
public class UserServiceImpl implements UserService {

	private static Logger log = Logger.getLogger(UserService.class);

	@Autowired
	private UserDao userDao;

	// Fetch all users from the backend
	@Transactional(readOnly = true)
	public List<User> findAll() {
		return userDao.findAll();
	}

	// Add a new user to the backend.
	@Transactional
	public Boolean add(User user) {
		userDao.add(user);
		return true;
	}

	// Update the selected user in the database.
	@Transactional
	public User updateName(Integer id, String name) {
		User user = userDao.updateUser(id, name);
		return user;
	}

	
	// Delete a user from the database.
	@Transactional
	public Boolean delete(Integer id) {
		boolean output = false;
		log.debug("Deleting an existing user from thedatabase; Entered user_id is= " + id);
		userDao.remove(id);
		return output;
	}

	// Fetching a single user details from the database.
	@Transactional(readOnly = true)
	public User findById(String id) {
		return userDao.findById(new Integer(id));
	}
}